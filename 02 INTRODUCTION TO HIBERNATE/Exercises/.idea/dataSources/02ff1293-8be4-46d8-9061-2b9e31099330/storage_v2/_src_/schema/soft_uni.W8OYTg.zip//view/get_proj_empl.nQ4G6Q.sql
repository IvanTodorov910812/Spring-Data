create view get_proj_empl as
select `e`.`employee_id` AS `employee_id`,
       `e`.`first_name`  AS `first_name`,
       `e`.`middle_name` AS `middle_name`,
       `e`.`last_name`   AS `last_name`,
       `p`.`name`        AS `name`,
       `p`.`description` AS `description`,
       `p`.`start_date`  AS `start_date`,
       `p`.`end_date`    AS `end_date`
from ((`soft_uni`.`employees_projects` `ep` join `soft_uni`.`employees` `e` on ((`ep`.`employee_id` = `e`.`employee_id`)))
         join `soft_uni`.`projects` `p` on ((`ep`.`project_id` = `p`.`project_id`)));

