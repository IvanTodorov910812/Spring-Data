create view get_addres_empl as
select `e`.`employee_id`  AS `employee_id`,
       `e`.`first_name`   AS `first_name`,
       `e`.`middle_name`  AS `middle_name`,
       `e`.`last_name`    AS `last_name`,
       `a`.`address_text` AS `address_text`,
       `t`.`name`         AS `name`
from ((`soft_uni`.`employees` `e` join `soft_uni`.`addresses` `a` on ((`e`.`address_id` = `a`.`address_id`)))
         join `soft_uni`.`towns` `t` on ((`a`.`town_id` = `t`.`town_id`)));

